const Loader = ({ height }) => {
	return (
		<div
			style={{ height: height ?? '100vh' }}
			className="d-flex align-items-center justify-content-center"
		>
			<div
				className="spinner-border text-danger"
				role="status"
			/>
		</div>
	);
};

export default Loader;
