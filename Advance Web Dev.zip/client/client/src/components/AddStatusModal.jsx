import { useMutation } from '@tanstack/react-query';
import { App, Button, Form, Input, Modal } from 'antd';
import axios from '../config/axios';

const AddStatusModal = ({ open, close, refetch }) => {
	const [form] = Form.useForm();
	const { message } = App.useApp();

	// create status update mutation
	const { mutate: createStatus, isPending } = useMutation({
		mutationFn: async (payload) => {
			await axios.post('/users/status-update', payload, { withCredentials: true });
		},
		onSuccess: () => {
			close();
			refetch();
			form.resetFields();
		},
		onError: (error) => {
			message.error(JSON.stringify(error.response.data));
		},
	});

	return (
		<Modal
			title="Post New Status"
			open={open}
			onCancel={close}
			footer={null}
			centered
			destroyOnClose
		>
			<Form
				onFinish={(values) => createStatus(values)}
				layout="vertical"
				requiredMark={false}
				form={form}
			>
				<Form.Item
					label="Status"
					name="status"
					rules={[{ required: true, message: 'Please input status message' }]}
					hasFeedback
				>
					<Input
						size="large"
						placeholder="How are you feeling today?"
					/>
				</Form.Item>

				<Form.Item className="mb-0">
					<Button
						type="primary"
						htmlType="submit"
						block
						size="large"
						loading={isPending}
						disabled={isPending}
					>
						Post Status
					</Button>
				</Form.Item>
			</Form>
		</Modal>
	);
};

export default AddStatusModal;
