import { Result } from 'antd';

const APIError = ({ height }) => {
	return (
		<div
			style={{ height: height ?? '100vh' }}
			className="d-flex align-items-center justify-content-center"
		>
			<Result
				status="error"
				title={<div className="fs-5">Something went wrong while fetching data.</div>}
			/>
		</div>
	);
};

export default APIError;
