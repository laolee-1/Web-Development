import { CloseCircleFilled, CloudUploadOutlined, Loading3QuartersOutlined } from '@ant-design/icons';
import { useMutation } from '@tanstack/react-query';
import { App, Button, Form, Image, Input, Modal, Upload } from 'antd';
import { useState } from 'react';
import axios from '../config/axios';

const AddCourseContentModal = ({ open, close, id, refetch }) => {
	const [form] = Form.useForm();
	const [fileType, setFileType] = useState(null);
	const { message } = App.useApp();

	// upload image mutation
	const { mutate: uploadFile, isPending: uploadFileLoading } = useMutation({
		mutationFn: async (file) => {
			const formData = new FormData();
			formData.append('file', file);
			const { data } = await axios.post('/users/file-upload', formData, {
				headers: {
					'Content-Type': 'multipart/form-data',
				},
			});

			const file_path = `http://localhost:8000${data.file_path}`;

			return file_path;
		},
		onError: (error) => {
			message.error(JSON.stringify(error.response.data));
		},
		onSuccess: (data) => {
			form.setFieldsValue({ file: data });
			setFileType(data.split('.').pop() ?? null);
		},
	});

	// add course content mutation
	const { mutate: addCourseContent, isPending: addCourseContentLoading } = useMutation({
		mutationFn: async (payload) => {
			await axios.post(`/courses/add-material/${id}`, payload, { withCredentials: true });
		},
		onError: (error) => {
			message.error(JSON.stringify(error.response.data));
		},
		onSuccess: () => {
			close();
			refetch();
		},
	});

	return (
		<Modal
			title="Add Course Content"
			open={open}
			onCancel={close}
			footer={null}
			centered
			destroyOnClose
		>
			<Form
				onFinish={(values) => addCourseContent(values)}
				layout="vertical"
				requiredMark={false}
				form={form}
			>
				<Form.Item
					label="Title"
					name="title"
					rules={[{ required: true, message: 'Please enter content title!' }]}
					hasFeedback
				>
					<Input
						placeholder="Content Title"
						size="large"
					/>
				</Form.Item>

				<Form.Item
					label="Content File"
					name="file"
					rules={[{ required: true, message: 'Please upload content file!' }]}
				>
					<Upload.Dragger
						multiple={false}
						showUploadList={false}
						customRequest={(e) => {
							uploadFile(e.file);
						}}
						disabled={uploadFileLoading || fileType !== null}
						accept="image/*, video/*, .pdf"
					>
						{uploadFileLoading ? (
							<div className="py-3">
								<Loading3QuartersOutlined
									spin
									className="fs-4 text-danger"
								/>
							</div>
						) : (
							<>
								<CloudUploadOutlined className="fs-3 text-danger" />
								<p className="ant-upload-text">Click or drag file to this area to upload.</p>
							</>
						)}
					</Upload.Dragger>
				</Form.Item>

				{fileType && (
					<div
						className="position-relative d-flex align-items-center justify-content-start pb-3"
						style={{
							width: 'fit-content',
						}}
					>
						<div
							className="d-flex justify-content-center align-items-center rounded border p-1"
							style={{ borderColor: '#D1D5DB' }}
						>
							{fileType &&
								(fileType.includes('png') || fileType.includes('jpeg') || fileType.includes('jpg') || fileType.includes('svg')) && (
									<Image
										height={96}
										src={form.getFieldValue('file')}
										alt="profile picture"
										width={'100%'}
									/>
								)}

							{/* if pdf */}
							{fileType && fileType.includes('pdf') && (
								<div className="fs-6">{form.getFieldValue('file').replace('http://localhost:8000/media/', '')}</div>
							)}

							{/* if video */}
							{fileType && (fileType.includes('mp4') || fileType.includes('webm') || fileType.includes('ogg')) && (
								<video
									height={96}
									src={form.getFieldValue('file')}
									controls
									width={'100%'}
								/>
							)}
						</div>
						<div
							className="position-absolute"
							style={{ right: '-0.25rem', top: '-0.25rem' }}
							role="button"
							onClick={() => {
								form.setFieldsValue({ file: undefined });
								setFileType(null);
							}}
						>
							<CloseCircleFilled className="fs-6 text-danger" />
						</div>
					</div>
				)}

				<Form.Item className="mb-0">
					<Button
						type="primary"
						htmlType="submit"
						block
						size="large"
						loading={[addCourseContentLoading, uploadFileLoading].some(Boolean)}
						disabled={[addCourseContentLoading, uploadFileLoading].some(Boolean)}
					>
						Add Content
					</Button>
				</Form.Item>
			</Form>
		</Modal>
	);
};

export default AddCourseContentModal;
