import { Avatar, Card, Tag } from 'antd';
import { Link } from 'react-router-dom';

const UserCard = ({ user }) => {
	return (
		<Link
			to={`/profile/${user.id}`}
			className="text-decoration-none text-dark"
		>
			<Card
				styles={{ body: { padding: 15 } }}
				hoverable
			>
				<div className="d-flex align-items-center justify-content-between gap-2 pb-2">
					<div>
						<div className="fs-6 lh-sm pt-2 fw-bold">{user.name}</div>
						<div className="pb-2 text-muted">@{user.username}</div>
						<Tag
							color={user.role === 'student' ? '#87d068' : '#108ee9'}
							className="text-capitalize"
						>
							{user.role}
						</Tag>
					</div>
					<Avatar
						src={user.dp}
						size={60}
					/>
				</div>

				<button
					type="button"
					className="btn btn-danger w-100 btn-sm"
				>
					View Profile
				</button>
			</Card>
		</Link>
	);
};

export default UserCard;
