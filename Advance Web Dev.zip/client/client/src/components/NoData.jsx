import { DatabaseOutlined } from '@ant-design/icons';
import { Result } from 'antd';

const NoData = ({ height, message }) => {
	return (
		<div
			style={{ height: height ?? '100vh' }}
			className="d-flex align-items-center justify-content-center"
		>
			<Result
				icon={<DatabaseOutlined className="text-danger" />}
				title={<div className="fs-5">{message ?? 'No data available.'}</div>}
			/>
		</div>
	);
};

export default NoData;
