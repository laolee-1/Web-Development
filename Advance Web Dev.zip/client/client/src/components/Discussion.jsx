import { Avatar, Button, Input, Space } from 'antd';
import { useContext, useEffect, useRef, useState } from 'react';
import { AuthContext } from '../context/AuthContext';

const Discussion = ({ course_id }) => {
    const [messages, setMessages] = useState([]);
    const { user } = useContext(AuthContext);
    const messagesEndRef = useRef(null);

    const [ws, setWs] = useState(null);
    const [message, setMessage] = useState('');

    useEffect(() => {
        const socket = new WebSocket(`ws://127.0.0.1:8000/ws/course_group_chat/${course_id}/`);

        socket.onopen = () => {
            setWs(socket);
        };

        socket.onmessage = (event) => {
            let payload = JSON.parse(event.data);
            setMessages((prev) => prev.concat(payload));
            setMessage('');
            messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        };

        socket.onclose = () => {
            setWs(null);
        };

        return () => {
            if (socket) {
                socket.close();
            }
        };
    }, [course_id]);

    const sendMessage = () => {
        if (ws) {
            let payload = {
                user_id: user?.id,
                username: user?.username,
                message: message,
                dp: user?.dp,
            };

            ws.send(JSON.stringify(payload));
        }
    };

    return (
        <>
            <div
                className="border rounded overflow-hidden position-relative"
                style={{
                    height: 'calc(65vh - 5rem)',
                }}
            >
                <div
                    className="overflow-auto"
                    style={{
                        height: 'calc(100% - 5rem)',
                        padding: '1rem',
                    }}
                >
                    <div
                        style={{
                            paddingBottom: '3rem',
                        }}
                    >
                        {messages.map((message, index) => (
                            <div
                                key={index}
                                className="mb-2 d-flex w-100"
                                style={{ justifyContent: message.data.user_id === user?.id ? 'flex-end' : 'flex-start' }}
                            >
                                <div
                                    className="d-flex gap-2 align-items-end"
                                    style={{
                                        width: 'fit-content',
                                        maxWidth: '45%',
                                        flexDirection: message.data.user_id === user?.id ? 'row' : 'row-reverse',
                                    }}
                                >
                                    <div>
                                        {message.data.user_id !== user?.id && <small className="ps-1">{message.data.username.split(' ')[0]}</small>}
                                        <div
                                            className="p-2 rounded-3"
                                            style={{
                                                backgroundColor: '#e6f7ff',
                                            }}
                                        >
                                            <span className="text-center">{message.data.message}</span>
                                        </div>
                                    </div>

                                    <div>
                                        <Avatar src={message.data.dp} />
                                    </div>
                                </div>
                            </div>
                        ))}

                        <div ref={messagesEndRef} />
                    </div>
                </div>

                <div className="position-absolute bottom-0 w-100 p-3 bg-white border-top d-flex justify-content-between align-items-center">
                    <Space.Compact
                        style={{
                            width: '100%',
                        }}
                    >
                        <Input
                            placeholder="Type a message..."
                            size="large"
                            value={message}
                            onPressEnter={sendMessage}
                            onChange={(e) => setMessage(e.target.value)}
                        />
                        <Button
                            type="primary"
                            size="large"
                            onClick={sendMessage}
                        >
                            Send
                        </Button>
                    </Space.Compact>
                </div>
            </div>
        </>
    );
};

export default Discussion;
