import { useQuery } from '@tanstack/react-query';
import { Avatar, Button, Modal, Table } from 'antd';
import { Link } from 'react-router-dom';
import axios from '../config/axios';
import Loader from './Loader';

const CourseStudentsListModal = ({ open, close, id }) => {
	// get course students query
	const {
		data: courseStudents,
		isLoading: courseStudentsLoading,
		isError: courseStudentsError,
	} = useQuery({
		queryKey: ['course_students', id],
		queryFn: async () => {
			const { data } = await axios.get(`/courses/enrolled-students/${id}`, { withCredentials: true });
			return data;
		},
		enabled: open && id !== undefined,
	});

	return (
		<Modal
			title="Students List"
			open={open}
			onCancel={close}
			footer={null}
			centered
			destroyOnClose
		>
			{courseStudentsLoading && <Loader height="20dvh" />}

			{courseStudentsError && (
				<div
					className="d-flex align-items-center justify-content-center fs-6"
					style={{
						height: '20dvh',
					}}
				>
					Something went wrong while fetching students.
				</div>
			)}

			{courseStudents && courseStudents.length === 0 && (
				<div
					className="d-flex align-items-center justify-content-center fs-6"
					style={{
						height: '20dvh',
					}}
				>
					No students enrolled in this course yet.
				</div>
			)}

			{courseStudents && courseStudents.length > 0 && (
				<Table
					size="small"
					columns={[
						{
							title: 'DP',
							dataIndex: 'dp',
							key: 'dp',
							render: (dp) => (
								<Avatar
									src={dp}
									size={30}
								/>
							),
						},
						{ title: 'Name', dataIndex: 'name', key: 'name' },
						{
							title: 'Username',
							dataIndex: 'username',
							key: 'username',
							render: (username) => `@${username}`,
						},
						{
							title: 'View Profile',
							key: 'action',
							dataIndex: 'id',
							render: (id) => (
								<Button
									type="primary"
									size="small"
									block
								>
									<Link
										to={`/profile/${id}`}
										className="text-decoration-none"
									>
										View Profile
									</Link>
								</Button>
							),
						},
					]}
					dataSource={courseStudents}
					bordered
					pagination={false}
				/>
			)}
		</Modal>
	);
};

export default CourseStudentsListModal;
