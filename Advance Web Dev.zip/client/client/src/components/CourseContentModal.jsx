import { Image, Modal } from 'antd';

const CourseContentModal = ({ open, close, content }) => {
	const fileType = content.file.split('.').pop();

	return (
		<Modal
			title={content.title}
			open={open}
			onCancel={close}
			footer={null}
			centered
			destroyOnClose
			width={fileType && fileType.includes('pdf') ? 1000 : 600}
		>
			{fileType && (fileType.includes('png') || fileType.includes('jpeg') || fileType.includes('jpg') || fileType.includes('svg')) && (
				<Image
					src={content.file}
					alt="profile picture"
					width={'100%'}
				/>
			)}

			{/* if pdf */}
			{fileType && fileType.includes('pdf') && (
				<div>
					<iframe
						src={content.file}
						width="100%"
						height="500px"
						title="pdf"
					/>
				</div>
			)}

			{/* if video */}
			{fileType && (fileType.includes('mp4') || fileType.includes('webm') || fileType.includes('ogg')) && (
				<video
					src={content.file}
					controls
					width={'100%'}
				/>
			)}
		</Modal>
	);
};

export default CourseContentModal;
