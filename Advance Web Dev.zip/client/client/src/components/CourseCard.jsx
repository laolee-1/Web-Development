import { App, Avatar, Badge, Card } from 'antd';
import { useContext } from 'react';
import { Link } from 'react-router-dom';
import axios from '../config/axios';
import { AuthContext } from '../context/AuthContext';

const CourseCard = ({ course, refetch }) => {
	const { user } = useContext(AuthContext);
	const { modal } = App.useApp();
	const handleCourseEnroll = async (id) => {
		modal.confirm({
			title: 'Are you sure you want to enroll in this course?',
			content: 'You will be able to access the course content and interact with the teacher and other students.',
			onOk: async () => {
				await axios.post(`/courses/enroll/${id}`, {}, { withCredentials: true });

				if (refetch) {
					refetch();
				}
			},
			okText: 'Confirm',
			centered: true,
		});
	};

	return (
		<Card
			hoverable
			cover={
				<div
					className="bg-info rounded-top"
					style={{
						height: 150,
					}}
				/>
			}
			styles={{ body: { padding: 15 } }}
		>
			<div className="h-100">
				<div className="fw-bold fs-5 text-danger">{course.name}</div>
				<div className="fw-bold">{course.code}</div>
				<div className="d-flex gap-1 align-items-center pt-3 pb-1">
					<Avatar
						src={course.teacher.dp}
						size={25}
					/>
					<span className="fw-bold text-muted">{course.teacher.name}</span>
				</div>

				<div className="pb-2 d-flex align-items-center gap-1">
					<div
						style={{
							marginTop: 2,
						}}
					>
						Enrolled:
					</div>
					<Badge
						count={course.students.length}
						showZero
					/>
				</div>

				{course.students.includes(Number(user?.id)) || course.teacher.id === user?.id ? (
					<Link to={`/course/${course.id}`}>
						<button
							type="button"
							className="btn btn-info w-100 text-white"
						>
							View Course
						</button>
					</Link>
				) : (
					<button
						type="button"
						className="btn btn-danger w-100"
						onClick={() => handleCourseEnroll(course.id)}
						disabled={user?.role === 'teacher'}
					>
						Enroll Now
					</button>
				)}
			</div>
		</Card>
	);
};

export default CourseCard;
