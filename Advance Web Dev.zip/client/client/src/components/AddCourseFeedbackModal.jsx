import { useMutation } from '@tanstack/react-query';
import { App, Button, Form, Input, Modal } from 'antd';
import axios from '../config/axios';


const AddCourseFeedbackModal = ({ open, close, refetch, id }) => {
	const [form] = Form.useForm();
	const { message } = App.useApp();

	// create course feedback mutation
	const { mutate: postFeedback, isPending } = useMutation({
		mutationFn: async (payload) => {
			await axios.post(`/courses/add-feedback/${id}`, payload, { withCredentials: true });
		},
		onSuccess: () => {
			message.success('Feedback posted successfully');
			close();
			refetch();
			form.resetFields();
		},
		onError: (error) => {
			message.error(JSON.stringify(error.response.data));
		},
	});

	return (
		<Modal
			title="Add Course Feedback"
			open={open}
			onCancel={close}
			footer={null}
			centered
			destroyOnClose
		>
			<Form
				onFinish={(values) => postFeedback(values)}
				layout="vertical"
				requiredMark={false}
				form={form}
			>
				<Form.Item
					label="Feedback"
					name="feedback"
					rules={[{ required: true, message: 'Please input feedback message' }]}
					hasFeedback
				>
					<Input
						size="large"
						placeholder="Write your feedback here..."
					/>
				</Form.Item>

				<Form.Item className="mb-0">
					<Button
						type="primary"
						htmlType="submit"
						block
						size="large"
						loading={isPending}
						disabled={isPending}
					>
						Post Feedback
					</Button>
				</Form.Item>
			</Form>
		</Modal>
	);
};

export default AddCourseFeedbackModal;