import { createContext, useEffect, useState } from 'react';
import Loader from '../components/Loader';
import axios from '../config/axios';

export const AuthContext = createContext({
	user: null,
	setUser: () => null,
	isAuthenticated: false,
	setIsAuthenticated: () => null,
});

export const AuthProvider = ({ children }) => {
	const [user, setUser] = useState(null);
	const [isAuthenticated, setIsAuthenticated] = useState(false);
	const [loading, setLoading] = useState(true);

	useEffect(() => {
		(async () => {
			try {
				const { data: user } = await axios.get('/users/authenticate', { withCredentials: true });
				setIsAuthenticated(true);
				setUser(user);
			} catch (error) {
				setIsAuthenticated(false);
				setUser(null);
			} finally {
				setLoading(false);
			}
		})();
	}, []);

	return loading ? (
		<Loader />
	) : (
		<AuthContext.Provider
			value={{
				user,
				setUser,
				isAuthenticated,
				setIsAuthenticated,
			}}
		>
			{children}
		</AuthContext.Provider>
	);
};
