import { ArrowRightOutlined, LogoutOutlined, SearchOutlined, UserOutlined } from '@ant-design/icons';
import { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import logo from '../assets/logo.svg';
import { AuthContext } from '../context/AuthContext';

const Layout = ({ children }) => {
	const navigate = useNavigate();
	const { user, setUser, setIsAuthenticated } = useContext(AuthContext);

	const handleLogout = () => {
		localStorage.clear();
		setIsAuthenticated(false);
		setUser(null);
		navigate('/login');
	};

	return (
		<>
			<div
				className="position-sticky sticky-top bg-danger"
				style={{ height: '3rem' }}
			>
				<div className="px-4 container-fluid">
					<div
						className="d-flex align-items-center justify-content-between"
						style={{ height: '3rem' }}
					>
						<Link to="/">
							<img
								src={logo}
								alt="logo"
								style={{
									height: 32,
									color: 'white',
								}}
							/>
						</Link>

						<div
							className="d-flex align-items-center"
							style={{ gap: '1rem' }}
						>
							{user?.role === 'teacher' && (
								<>
									<div className="fw-bold fs-5">
										<Link
											to="/search"
											style={{ color: 'white' }}
											className="text-decoration-none"
										>
											<SearchOutlined className="text-base" />
										</Link>
									</div>
								</>
							)}

							<div className="fw-bold fs-5">
								<Link
									to={`/profile/${user?.id}`}
									style={{ color: 'white' }}
									className="text-decoration-none"
								>
									<UserOutlined className="text-base" />
								</Link>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div
				className="position-fixed bg-white vh-100 border-end"
				style={{
					width: 250,
				}}
			>
				<div>
					<Link
						to="/"
						className="text-decoration-none fw-bold text-dark"
					>
						<div className="px-3 py-2 border-bottom d-flex align-items-center justify-content-between">
							<span>Home</span>

							<ArrowRightOutlined className="text-muted" />
						</div>
					</Link>

					{user?.role === 'teacher' && (
						<>
							<Link
								to="/create-course"
								className="text-decoration-none fw-bold text-dark"
							>
								<div className="px-3 py-2 border-bottom d-flex align-items-center justify-content-between">
									<span>Create Course</span>

									<ArrowRightOutlined className="text-muted" />
								</div>
							</Link>

							<Link
								to="/search"
								className="text-decoration-none fw-bold text-dark"
							>
								<div className="px-3 py-2 border-bottom d-flex align-items-center justify-content-between">
									<span>Search Users</span>

									<ArrowRightOutlined className="text-muted" />
								</div>
							</Link>
						</>
					)}

					{user?.role === 'student' && (
						<>
							<Link
								to="/my-learning"
								className="text-decoration-none fw-bold text-dark"
							>
								<div className="px-3 py-2 border-bottom d-flex align-items-center justify-content-between">
									<span>My Learning</span>

									<ArrowRightOutlined className="text-muted" />
								</div>
							</Link>
						</>
					)}

					<Link
						to={`/profile/${user?.id}`}
						className="text-decoration-none fw-bold text-dark"
					>
						<div className="px-3 py-2 border-bottom d-flex align-items-center justify-content-between">
							<span>My Profile</span>

							<ArrowRightOutlined className="text-muted" />
						</div>
					</Link>

					<div
						className="px-3 py-2 border-bottom d-flex align-items-center justify-content-between fw-bold text-dark"
						role="button"
						onClick={handleLogout}
					>
						<span>Logout</span>

						<LogoutOutlined className="text-muted" />
					</div>
				</div>
			</div>

			<div
				style={{
					marginLeft: 250,
				}}
				className="p-3"
			>
				{children}
			</div>
		</>
	);
};

export default Layout;
