import { Button, Result } from 'antd';
import { Link } from 'react-router-dom';

const NotFound = () => {
	return (
		<div className="d-flex flex-column align-items-center justify-content-center vh-100">
			<Result
				status="404"
				title="404"
				subTitle="Sorry, the page you visited does not exist."
				extra={
					<Button type="primary">
						<Link
							to={'/'}
							className="text-decoration-none"
						>
							Back to Home
						</Link>
					</Button>
				}
			/>
		</div>
	);
};

export default NotFound;
