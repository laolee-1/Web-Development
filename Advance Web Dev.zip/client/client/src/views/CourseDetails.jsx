import { CalendarOutlined, EyeOutlined, MinusCircleOutlined, PlusCircleOutlined, PlusOutlined } from '@ant-design/icons';
import { useMutation, useQuery } from '@tanstack/react-query';
import { App, Button, Card, Form, Input } from 'antd';
import { useContext, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import Layout from '../Layout/Layout';
import APIError from '../components/APIError';
import AddCourseContentModal from '../components/AddCourseContentModal';
import AddCourseFeedbackModal from '../components/AddCourseFeedbackModal';
import CourseContentModal from '../components/CourseContentModal';
import CourseStudentsListModal from '../components/CourseStudentsListModal';
import Discussion from '../components/Discussion';
import Loader from '../components/Loader';
import NoData from '../components/NoData';
import axios from '../config/axios';
import { AuthContext } from '../context/AuthContext';

const CourseDetails = () => {
	const { id } = useParams();
	const { user } = useContext(AuthContext);
	const [courseContentSelected, setCourseContentSelected] = useState({
		modal: false,
		data: null,
	});
	const [addCourseFeedbackModalOpen, setAddCourseFeedbackModalOpen] = useState(false);
	const [addCourseContentModalOpen, setAddCourseContentModalOpen] = useState(false);
	const [courseStudentsListModalOpen, setCourseStudentsListModalOpen] = useState(false);
	const { message } = App.useApp();
	const [create_notes_form] = Form.useForm();

	// get course details query
	const {
		data: course,
		isLoading: courseLoading,
		isError: courseError,
	} = useQuery({
		queryKey: ['course_details', id],
		queryFn: async () => {
			// fetch course details by id
			const { data } = await axios.get(`/courses/${id}`, { withCredentials: true });

			return data;
		},
		enabled: id !== undefined,
	});

	// get course materials query
	const {
		data: courseMaterials,
		isLoading: courseMaterialsLoading,
		isError: courseMaterialsError,
		refetch: refetchCourseMaterials,
	} = useQuery({
		queryKey: ['course_materials', id],
		queryFn: async () => {
			// fetch course materials by id
			const { data } = await axios.get(`/courses/materials/${id}`, { withCredentials: true });

			return data;
		},
		enabled: id !== undefined,
	});

	// get course feedback query for teacher
	const {
		data: courseFeedbackTeacher,
		isLoading: courseFeedbackTeacherLoading,
		isError: courseFeedbackTeacherError,
		refetch: refetchCourseFeedbackTeacher,
	} = useQuery({
		queryKey: ['course_feedback', id],
		queryFn: async () => {
			// fetch course feedback by id
			const { data } = await axios.get(`/courses/feedbacks/${id}`, { withCredentials: true });

			return data;
		},
		enabled: id !== undefined && user?.role === 'teacher',
	});

	// get course private notes query
	const {
		data: coursePrivateNotes,
		isLoading: coursePrivateNotesLoading,
		isError: coursePrivateNotesError,
		refetch: refetchCoursePrivateNotes,
	} = useQuery({
		queryKey: ['course_private_notes', id],
		queryFn: async () => {
			// fetch course private notes by id
			const { data } = await axios.get(`/courses/private-notes/${id}`, { withCredentials: true });

			return data;
		},
		enabled: id !== undefined,
	});

	// create bulk notes mutation
	const { mutate: createBulkNotes, isPending: createBulkNotesLoading } = useMutation({
		mutationFn: async (notes) => {
			await axios.post(`/courses/add-private-notes-in-bulk/${id}`, notes, { withCredentials: true });
		},
		onSuccess: () => {
			message.success("Notes has been queued for creation. It'll be created in a while.");
			create_notes_form.resetFields();
			refetchCoursePrivateNotes();
		},
		onError: (error) => {
			message.error(JSON.stringify(error.response.data));
		},
	});

	return (
		<Layout>
			<div
				className="d-flex flex-column justify-content-center rounded px-4 bg-danger"
				style={{ height: '11rem' }}
			>
				{courseLoading && <Loader height="7.5rem" />}

				{courseError && (
					<div
						className="d-flex align-items-center justify-content-center text-white"
						style={{
							height: '7.5rem',
						}}
					>
						Something went wrong while fetching course details.
					</div>
				)}

				{course && (
					<div className="d-flex flex-column gap-1 text-white">
						<h2 className="mb-0">{course.name}</h2>

						<div>
							Course Teacher: <span className="text-decoration-underline">{course.teacher.name}</span>
						</div>

						<div className="d-flex align-items-center gap-1">
							<div>Last Updated - </div>
							<div>{new Date(course.updated_at).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</div>
						</div>

						<div className="d-flex align-items-center gap-2">
							<div>{course.students.length} Students </div>

							{user && user.role === 'teacher' && user.id === course.teacher.id && (
								<EyeOutlined
									title="See Students"
									className="fs-5"
									role="button"
									onClick={() => setCourseStudentsListModalOpen(true)}
								/>
							)}
						</div>
					</div>
				)}
			</div>

			{course && (
				<CourseStudentsListModal
					open={courseStudentsListModalOpen}
					close={() => setCourseStudentsListModalOpen(false)}
					id={course.id}
				/>
			)}

			<div className="d-flex align-items-center justify-content-between gap-2 pt-4">
				<h2 className="fs-3 mb-0">Course Content</h2>

				{course && user && course.teacher.id === user.id && (
					<Button
						type="dashed"
						icon={<PlusCircleOutlined />}
						onClick={() => setAddCourseContentModalOpen(true)}
					>
						Add Course Content
					</Button>
				)}

				{course && user && course.students.includes(user.id) && (
					<Button
						type="primary"
						icon={<PlusCircleOutlined />}
						onClick={() => setAddCourseFeedbackModalOpen(true)}
					>
						Give Feedback
					</Button>
				)}
			</div>

			{addCourseContentModalOpen && id && (
				<AddCourseContentModal
					open={addCourseContentModalOpen}
					close={() => setAddCourseContentModalOpen(false)}
					refetch={refetchCourseMaterials}
					id={id}
				/>
			)}

			{courseMaterialsLoading && <Loader height="30dvh" />}

			{courseMaterialsError && <APIError height={'30dvh'} />}

			{courseMaterials && courseMaterials.length === 0 && (
				<NoData
					height={'30vh'}
					message={'No course content available yet.'}
				/>
			)}

			{courseMaterials && courseMaterials.length > 0 && (
				<div className="row pt-3">
					{courseMaterials.map((item, i) => (
						<div
							className="col-lg-3"
							key={i}
						>
							<Card
								styles={{
									body: {
										padding: 15,
									},
								}}
								hoverable
							>
								<div className="d-flex align-items-center justify-content-between gap-2">
									<div className="fs-5 fw-bold">
										{i + 1}. {item.title}
									</div>

									<Button
										type="primary"
										onClick={() => setCourseContentSelected({ modal: true, data: item })}
										style={{ width: 90, height: 30 }}
										size="small"
									>
										View
									</Button>
								</div>
							</Card>
						</div>
					))}
				</div>
			)}

			{courseContentSelected.data && (
				<CourseContentModal
					open={courseContentSelected.modal}
					close={() => setCourseContentSelected((prev) => ({ ...prev, modal: false }))}
					content={courseContentSelected.data}
				/>
			)}

			{user && user.role === 'teacher' && (
				<>
					<h3 className="pt-4 mb-0">Course Feedbacks</h3>

					{courseFeedbackTeacherLoading && <Loader height="20dvh" />}

					{courseFeedbackTeacherError && <APIError height={'20dvh'} />}

					{courseFeedbackTeacher && courseFeedbackTeacher.length === 0 && (
						<NoData
							height={'20vh'}
							message={'No course feedbacks available yet.'}
						/>
					)}

					{courseFeedbackTeacher && courseFeedbackTeacher.length > 0 && (
						<div className="d-flex flex-column gap-3 pt-2">
							{courseFeedbackTeacher.map((item) => (
								<Card
									key={item.id}
									styles={{
										body: {
											padding: 10,
										},
									}}
									hoverable
									className="rounded-0"
								>
									<div className="d-flex align-items-center gap-1">
										<div>"{item.feedback}"</div>

										<div>
											By{' '}
											<Link
												to={`/profile/${item.student.id}`}
												className="text-decoration-none"
											>
												{item.student.name}
											</Link>
										</div>
									</div>

									<div className="d-flex align-items-center gap-2">
										<CalendarOutlined />
										<p className="mb-0 mt-1">
											{new Date(item.created_at).toLocaleDateString('en-US', {
												month: 'long',
												day: 'numeric',
												year: 'numeric',
											})}
										</p>
									</div>
								</Card>
							))}
						</div>
					)}

					<h2 className="fs-3 mt-3">Notes</h2>
					<div className="row">
						<div className="col-lg-6">
							<Card styles={{ body: { padding: 0, height: 600, overflow: 'auto' } }}>
								<h6 className="position-sticky sticky-top bg-white py-2 px-3 rounded-top">All Notes</h6>

								<div className="px-3 pb-3">
									{coursePrivateNotesLoading && <Loader height="500px" />}

									{coursePrivateNotesError && <APIError height={'500px'} />}

									{coursePrivateNotes && coursePrivateNotes.length === 0 && (
										<NoData
											height={'500px'}
											message={'No notes available yet.'}
										/>
									)}

									{coursePrivateNotes && coursePrivateNotes.length > 0 && (
										<div className="d-flex flex-column gap-3 pt-2">
											{coursePrivateNotes.map((item) => (
												<Card
													key={item.id}
													styles={{
														body: {
															padding: 10,
														},
													}}
													hoverable
													className="rounded-0"
												>
													<div className="d-flex align-items-center gap-1">
														<div>{item.note}</div>
													</div>

													<div className="d-flex align-items-center gap-2">
														<CalendarOutlined />
														<p className="mb-0 mt-1">
															{new Date(item.created_at).toLocaleDateString('en-US', {
																month: 'long',
																day: 'numeric',
																year: 'numeric',
															})}
														</p>
													</div>
												</Card>
											))}
										</div>
									)}
								</div>
							</Card>
						</div>
						<div className="col-lg-6">
							<Card styles={{ body: { padding: 0, height: 600, overflow: 'auto' } }}>
								<h6 className="position-sticky sticky-top bg-white py-2 px-3 rounded-top">Save Notes</h6>

								<div className="px-3">
									<Form
										name="notes-form"
										onFinish={(values) => createBulkNotes(values)}
										initialValues={{
											notes: [''],
										}}
										form={create_notes_form}
									>
										<Form.List
											name="notes"
											rules={[
												{
													validator: async (_, notes) => {
														if (!notes || notes.length < 1) {
															return Promise.reject(new Error('At least 1 notes is required'));
														}
													},
												},
											]}
										>
											{(fields, { add, remove }, { errors }) => (
												<>
													{fields.map((field) => (
														<Form.Item
															required={true}
															key={field.key}
														>
															<Form.Item
																{...field}
																validateTrigger={['onChange', 'onBlur']}
																rules={[
																	{
																		required: true,
																		whitespace: true,
																		message: 'Please input note or delete this field.',
																	},
																]}
																noStyle
															>
																<Input
																	placeholder="Write your notes here..."
																	style={{
																		width: 'calc(100% - 60px)',
																	}}
																	size="large"
																/>
															</Form.Item>
															{fields.length > 1 ? (
																<MinusCircleOutlined
																	className="dynamic-delete-button"
																	onClick={() => remove(field.name)}
																/>
															) : null}
														</Form.Item>
													))}
													<Form.Item>
														<Button
															type="dashed"
															onClick={() => add()}
															block
															icon={<PlusOutlined />}
														>
															Add New Note
														</Button>
													</Form.Item>
												</>
											)}
										</Form.List>
										<Form.Item>
											<Button
												type="primary"
												htmlType="submit"
												block
												loading={createBulkNotesLoading}
												disabled={createBulkNotesLoading}
											>
												Save Notes
											</Button>
										</Form.Item>
									</Form>
								</div>
							</Card>
						</div>
					</div>
				</>
			)}

			{/* discussion */}
			<div className="d-flex align-items-center justify-content-between gap-2 mt-3">
				<h2 className="fs-3">Discussion</h2>
				<div className="text-success">(Realtime)</div>
			</div>
			{id && <Discussion course_id={id} />}
			<div className="pt-2 text-danger fw-bold">
				<small>Note: This discussion is realtime and will remain save as long as this page is open.</small>
			</div>

			{addCourseFeedbackModalOpen && id && (
				<AddCourseFeedbackModal
					open={addCourseFeedbackModalOpen}
					close={() => setAddCourseFeedbackModalOpen(false)}
					id={id}
					refetch={refetchCourseFeedbackTeacher}
				/>
			)}
		</Layout>
	);
};

export default CourseDetails;
