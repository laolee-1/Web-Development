import { useQuery } from '@tanstack/react-query';
import Layout from '../Layout/Layout';
import APIError from '../components/APIError';
import CourseCard from '../components/CourseCard';
import Loader from '../components/Loader';
import NoData from '../components/NoData';
import axios from '../config/axios';

const MyLearning = () => {
	// get all own courses query
	const { data, isLoading, isError } = useQuery({
		queryKey: ['own_courses'],
		queryFn: async () => {
			const { data } = await axios.get('/courses', { withCredentials: true, params: { own_courses: 'True' } });
			return data;
		},
	});

	return (
		<Layout>
			<h2 className="fs-3 border-bottom pb-2">My Learning</h2>

			{isLoading && <Loader height="70dvh" />}

			{isError && <APIError height={'70dvh'} />}

			{data && data.length === 0 && (
				<NoData
					height={'70vh'}
					message={'You have not enrolled in any courses yet.'}
				/>
			)}

			{data && data.length > 0 && (
				<div className="row pt-1 g-4">
					{data.map((course) => (
						<div
							className="col-lg-3"
							key={course.id}
						>
							<CourseCard course={course} />
						</div>
					))}
				</div>
			)}
		</Layout>
	);
};

export default MyLearning;
