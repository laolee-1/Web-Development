import { useMutation } from '@tanstack/react-query';
import { Alert, App, Button, Form, Input } from 'antd';
import { useNavigate } from 'react-router-dom';
import Layout from '../Layout/Layout';
import axios from '../config/axios';

const CreateCourse = () => {
	const navigate = useNavigate();
	const { message } = App.useApp();

	// create course mutation
	const { mutate: createCourse, isPending } = useMutation({
		mutationFn: async (payload) => {
			await axios.post('/courses', payload, { withCredentials: true });
		},
		onSuccess: () => {
			navigate('/');
		},
		onError: (error) => {
			message.error(JSON.stringify(error.response.data));
		},
	});

	return (
		<Layout>
			<h1 className="fs-3 mb-0">Create New Course</h1>
			<p className="mb-0 text-muted">Introduce a fresh course to learners and commence your instruction now!</p>

			<div className="pt-3">
				<Alert
					message="Create a new course by providing basic details such as name, code, and description. Once the course is set up, you can proceed to add the course content."
					type="error"
					closable
				/>
			</div>

			<Form
				onFinish={(values) => createCourse(values)}
				layout="vertical"
				requiredMark={false}
				className="pt-3"
			>
				<Form.Item
					label="Course Name"
					name="name"
					rules={[{ required: true, message: 'Please enter course name!' }]}
					hasFeedback
				>
					<Input
						size="large"
						placeholder="Introduction to Computer Science"
					/>
				</Form.Item>

				<Form.Item
					label="Course Code"
					name="code"
					rules={[{ required: true, message: 'Please enter course code!' }]}
					hasFeedback
				>
					<Input
						size="large"
						placeholder="CM3034"
					/>
				</Form.Item>

				<Form.Item
					label="Course Description"
					name="description"
					rules={[{ required: true, message: 'Please enter course description!' }]}
					hasFeedback
				>
					<Input.TextArea
						rows={4}
						placeholder="This course is designed to introduce students to the fundamental concepts of computer science."
					/>
				</Form.Item>

				<Form.Item>
					<Button
						type="primary"
						htmlType="submit"
						size="large"
						loading={isPending}
						disabled={isPending}
						block
					>
						Create Course
					</Button>
				</Form.Item>
			</Form>
		</Layout>
	);
};

export default CreateCourse;
