import {
	CloseCircleFilled,
	CloudUploadOutlined,
	Loading3QuartersOutlined,
	LockOutlined,
	LoginOutlined,
	UserAddOutlined,
	UserOutlined,
} from '@ant-design/icons';
import { useMutation } from '@tanstack/react-query';
import { App, Button, Form, Image, Input, Segmented, Select, Upload } from 'antd';
import { useContext, useState } from 'react';
import { Navigate } from 'react-router-dom';
import undrawLogin from '../assets/undraw_login.svg';
import axios from '../config/axios';
import { AuthContext } from '../context/AuthContext';

const Auth = () => {
	const { message } = App.useApp();
	const { isAuthenticated, setIsAuthenticated, setUser } = useContext(AuthContext);
	const [activeTab, setActiveTab] = useState('login');
	const [register_form] = Form.useForm();
	const dp = Form.useWatch('dp', register_form);

	// upload image mutation
	const { mutate: uploadImage, isPending: uploadImageLoading } = useMutation({
		mutationFn: async (image) => {
			const formData = new FormData();
			formData.append('file', image);
			const { data } = await axios.post('/users/file-upload', formData, {
				headers: {
					'Content-Type': 'multipart/form-data',
				},
			});

			const file_path = `http://localhost:8000${data.file_path}`;

			return file_path;
		},
		onError: (error) => {
			message.error(JSON.stringify(error.response.data));
		},
		onSuccess: (data) => {
			register_form.setFieldsValue({ dp: data });
		},
	});

	// register mutation
	const { mutate: register, isPending: registerLoading } = useMutation({
		mutationFn: async (payload) => {
			await axios.post('/users/register', payload);
		},
		onError: (error) => {
			message.error(JSON.stringify(error.response.data));
		},
		onSuccess: () => {
			message.success('Registered successfully, logging in...');

			login({
				username: register_form.getFieldValue('username'),
				password: register_form.getFieldValue('password'),
			});
		},
	});

	// login mutation
	const { mutate: login, isPending: loginLoading } = useMutation({
		mutationFn: async (payload) => {
			const { data } = await axios.post('/users/login', payload);
			return data;
		},
		onError: (error) => {
			if (error.response && error.response.data && typeof error.response.data === 'object' && 'error' in error.response.data) {
				message.error(error.response.data.error);
			} else {
				message.error('A server error occurred. Please try again later.');
			}
		},
		onSuccess: (data) => {
			localStorage.setItem('device_id', data.access_token);
			setIsAuthenticated(true);
			setUser(data.user);
		},
	});

	// if user is already logged in redirect to home page
	if (isAuthenticated) {
		return (
			<Navigate
				to="/"
				replace
			/>
		);
	}

	return (
		<>
			<div className="row g-0">
				<div className="col">
					<div className="d-flex flex-column justify-content-center vh-100 align-items-center">
						<h2 className="fs-3 fw-bold mb-0">Welcome Back</h2>
						<p className="mb-0 text-muted fs-6">Welcome Back, Please enter your details.</p>

						<div
							style={{
								width: 280,
							}}
							className="pt-3"
						>
							<Segmented
								options={[
									{
										label: 'Login',
										value: 'login',
										icon: <LoginOutlined />,
									},
									{
										label: 'Register',
										value: 'register',
										icon: <UserAddOutlined />,
									},
								]}
								onChange={(value) => {
									setActiveTab(value);
								}}
								size="large"
								value={activeTab}
								block
							/>
						</div>

						{activeTab === 'login' && (
							<Form
								onFinish={(values) => login(values)}
								layout="vertical"
								requiredMark={false}
								className="pt-4"
								style={{
									minWidth: 450,
								}}
							>
								<Form.Item
									name="username"
									rules={[{ required: true, message: 'Please enter your username!' }]}
									hasFeedback
								>
									<Input
										placeholder="Enter Your Username"
										size="large"
										prefix={<UserOutlined />}
										style={{
											height: 45,
										}}
									/>
								</Form.Item>
								<Form.Item
									name="password"
									rules={[{ required: true, message: 'Please enter your password!' }]}
									hasFeedback
								>
									<Input.Password
										size="large"
										placeholder="Enter Your Password"
										prefix={<LockOutlined />}
										style={{
											height: 45,
										}}
									/>
								</Form.Item>

								<Form.Item className="mb-3">
									<Button
										type="primary"
										htmlType="submit"
										block
										size="large"
										loading={loginLoading}
										disabled={loginLoading}
									>
										Login
									</Button>
								</Form.Item>
							</Form>
						)}

						{activeTab === 'register' && (
							<Form
								onFinish={(values) => register(values)}
								layout="vertical"
								requiredMark={false}
								className="pt-4"
								form={register_form}
								style={{
									minWidth: 450,
								}}
							>
								<Form.Item
									name="name"
									rules={[{ required: true, message: 'Please enter your name!' }]}
									hasFeedback
								>
									<Input
										placeholder="Enter Your Name"
										size="large"
										style={{
											height: 45,
										}}
										prefix={<UserOutlined />}
									/>
								</Form.Item>

								<Form.Item
									name="username"
									rules={[{ required: true, message: 'Please enter your username!' }]}
									hasFeedback
								>
									<Input
										placeholder="Enter Your Username"
										size="large"
										style={{
											height: 45,
										}}
										prefix={<UserOutlined />}
									/>
								</Form.Item>
								<Form.Item
									name="password"
									rules={[{ required: true, message: 'Please enter your password!' }]}
									hasFeedback
								>
									<Input.Password
										size="large"
										placeholder="Enter Your Password"
										style={{
											height: 45,
										}}
										prefix={<LockOutlined />}
									/>
								</Form.Item>

								<Form.Item
									name="role"
									rules={[{ required: true, message: 'Please select your role!' }]}
									hasFeedback
								>
									<Select
										size="large"
										options={[
											{
												label: 'Student',
												value: 'student',
											},
											{
												label: 'Teacher',
												value: 'teacher',
											},
										]}
										placeholder="What are you?"
										style={{
											height: 45,
										}}
									/>
								</Form.Item>

								<Form.Item
									name="dp"
									rules={[{ required: true, message: 'Please upload your profile picture!' }]}
								>
									<Upload.Dragger
										multiple={false}
										showUploadList={false}
										customRequest={(e) => {
											uploadImage(e.file);
										}}
										disabled={uploadImageLoading}
										accept="image/*"
									>
										{uploadImageLoading ? (
											<div className="py-3">
												<Loading3QuartersOutlined
													spin
													className="fs-5 text-danger"
												/>
											</div>
										) : (
											<>
												<CloudUploadOutlined className="fs-3 text-danger" />
												<p className="ant-upload-text">Click to upload profile picture.</p>
											</>
										)}
									</Upload.Dragger>
								</Form.Item>

								{!uploadImageLoading && dp && (
									<div
										className="position-relative d-flex align-items-center justify-content-start pb-3"
										style={{
											width: 'fit-content',
										}}
									>
										<div
											className="d-flex justify-content-center align-items-center rounded border p-1"
											style={{ borderColor: '#D1D5DB' }}
										>
											<Image
												height={96}
												src={dp}
												alt="profile picture"
												width={'100%'}
											/>
										</div>
										<div
											className="position-absolute"
											style={{ top: '-0.25rem', right: '-0.25rem' }}
											role="button"
											onClick={() => {
												register_form.setFieldsValue({ dp: undefined });
											}}
										>
											<CloseCircleFilled className="fs-6 text-danger" />
										</div>
									</div>
								)}

								<Form.Item className="mb-3">
									<Button
										type="primary"
										htmlType="submit"
										block
										size="large"
										loading={[registerLoading, loginLoading].some(Boolean)}
										disabled={[registerLoading, uploadImageLoading, loginLoading].some(Boolean)}
									>
										Register
									</Button>
								</Form.Item>
							</Form>
						)}
					</div>
				</div>
				<div className="col">
					<div className="bg-danger vh-100">
						<div className="d-flex flex-column justify-content-center vh-100">
							<img
								src={undrawLogin}
								alt="login"
								className="img-fluid w-full"
								style={{
									height: 280,
								}}
							/>
						</div>
					</div>
				</div>
			</div>
		</>
	);
};

export default Auth;
