import { useQuery } from '@tanstack/react-query';
import { Button, Form, Input, Radio } from 'antd';
import { useState } from 'react';
import Layout from '../Layout/Layout';
import APIError from '../components/APIError';
import Loader from '../components/Loader';
import NoData from '../components/NoData';
import UserCard from '../components/UserCard';
import axios from '../config/axios';

const Search = () => {
	const [searchTerm, setSearchTerm] = useState('');
	const [role, setRole] = useState('');
	const [form] = Form.useForm();

	const {
		data: users,
		isLoading,
		isError,
	} = useQuery({
		queryKey: ['users', searchTerm, role],
		queryFn: async () => {
			const { data } = await axios.get('/users/search', {
				withCredentials: true,
				params: {
					search_term: searchTerm,
					role,
				},
			});
			return data;
		},
		enabled: searchTerm !== '' || role !== '',
	});

	return (
		<Layout>
			<div className="row">
				<div
					className="col-lg-2 border-end"
					style={{
						height: 'calc(100vh - 5rem)',
					}}
				>
					<div className="d-flex align-items-center justify-content-between">
						<h4>Filter</h4>
						{searchTerm !== '' || role !== '' ? (
							<p
								className="mb-0 text-decoration-underline"
								onClick={() => {
									setSearchTerm('');
									setRole('');
									form.resetFields();
								}}
								role="button"
							>
								Clear
							</p>
						) : null}
					</div>

					<Form
						size="large"
						onFinish={(v) => {
							setSearchTerm(v.search_term);
							setRole(v.role);
						}}
						className="d-flex flex-column gap-2"
						form={form}
					>
						<Form.Item
							name="search_term"
							className="mb-0"
						>
							<Input placeholder="Search by name" />
						</Form.Item>

						<Form.Item
							name="role"
							className="mb-0"
						>
							<Radio.Group
								options={[
									{
										label: 'Teacher',
										value: 'teacher',
									},
									{
										label: 'Student',
										value: 'student',
									},
								]}
							/>
						</Form.Item>
						<Form.Item className="mb-0">
							<Button
								type="primary"
								htmlType="submit"
								block
								loading={isLoading}
								disabled={isLoading}
							>
								Search
							</Button>
						</Form.Item>
					</Form>
				</div>
				<div className="col-lg-10">
					{!isLoading && !isError && !users && (
						<NoData
							height={'85vh'}
							message={'Search for users.'}
						/>
					)}

					{isLoading && <Loader height="85dvh" />}

					{isError && <APIError height={'85vh'} />}

					{users && users.length === 0 && (
						<NoData
							height={'85vh'}
							message={'No users found.'}
						/>
					)}

					{users && users.length > 0 && (
						<div className="pt-3">
							<div className="row g-3">
								{users.map((user) => (
									<div
										className="col-lg-3"
										key={user.id}
									>
										<UserCard user={user} />
									</div>
								))}
							</div>
						</div>
					)}
				</div>
			</div>
		</Layout>
	);
};

export default Search;
