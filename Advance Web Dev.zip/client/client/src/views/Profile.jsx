import { CalendarOutlined, PlusCircleOutlined } from '@ant-design/icons';
import { useQuery } from '@tanstack/react-query';
import { Avatar, Button, Card, Divider, Tabs, Tag } from 'antd';
import { useContext, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import Layout from '../Layout/Layout';
import APIError from '../components/APIError';
import AddStatusModal from '../components/AddStatusModal';
import CourseCard from '../components/CourseCard';
import Loader from '../components/Loader';
import NoData from '../components/NoData';
import axios from '../config/axios';
import { AuthContext } from '../context/AuthContext';

const Profile = () => {
	const { id } = useParams();
	const { user } = useContext(AuthContext);
	const [statusModalOpen, setStatusModalOpen] = useState(false);

	// get user profile query
	const { data, isLoading, isError, refetch } = useQuery({
		queryKey: ['user_profile', id],
		queryFn: async () => {
			const { data } = await axios.get(`/users/${id}`, { withCredentials: true });
			return data;
		},
	});

	// get students own feedback query
	const {
		data: userFeedback,
		isLoading: userFeedbackLoading,
		isError: userFeedbackError,
	} = useQuery({
		queryKey: ['user_feedback'],
		queryFn: async () => {
			const { data } = await axios.get(`/courses/own-feedbacks`, { withCredentials: true });

			return data;
		},
		enabled: data?.user.id === user?.id && data?.user.role === 'student',
	});

	return (
		<Layout>
			{isLoading && <Loader height="75dvh" />}

			{isError && <APIError height={'70dvh'} />}

			{data && (
				<>
					<div className="d-flex flex-column align-items-center g-1">
						<Avatar
							src={data.user.dp}
							size={110}
							className="border border-2 border-info bg-white"
						/>
						<div className="fs-3 fw-bold">{data.user.name}</div>

						<div className="d-flex align-items-center">
							<div className="text-muted">@{data.user.username}</div>

							<Divider
								type="vertical"
								style={{
									borderInlineStartColor: 'rgba(0,0,0,0.5)',
									height: '1.3rem',
								}}
							/>

							<div className="text-muted">
								Since {new Date(data.user.created_at).toLocaleDateString('en-US', { day: '2-digit', month: 'long', year: 'numeric' })}
							</div>

							<Divider
								type="vertical"
								style={{
									borderInlineStartColor: 'rgba(0,0,0,0.5)',
									height: '1.3rem',
								}}
							/>

							<div className="text-capitalize">
								<Tag color="#108ee9">{data.user.role}</Tag>
							</div>
						</div>
					</div>

					{data.user.role === 'teacher' && (
						<>
							<Tabs
								defaultActiveKey="1"
								items={[
									{
										key: '1',
										label: 'Running Courses',
										children: (
											<>
												{data.created_courses.length === 0 && (
													<>
														<div
															className="d-flex flex-column align-items-center justify-content-center gap-2 fs-6"
															style={{ height: '40vh' }}
														>
															<div>Not created any courses yet.</div>

															{data.user.id === user?.id && (
																<Link to={'/create-course'}>
																	<Button type={'primary'}>Create Course</Button>
																</Link>
															)}
														</div>
													</>
												)}

												<div className="row pt-1 g-4">
													{data.created_courses.map((course) => (
														<div
															className="col-lg-3"
															key={course.id}
														>
															<CourseCard course={course} />
														</div>
													))}
												</div>
											</>
										),
									},
								]}
								size="large"
							/>
						</>
					)}

					{data.user.role === 'student' && (
						<>
							<Tabs
								defaultActiveKey="1"
								items={[
									{
										key: '1',
										label: 'Enrolled Courses',
										children: (
											<>
												{data.enrolled_courses.length === 0 && (
													<>
														<div
															className="d-flex flex-column align-items-center justify-content-center gap-2 fs-6"
															style={{ height: '40vh' }}
														>
															<div>Not enrolled in any courses yet.</div>

															{user?.id === data.user.id && (
																<Link to={'/'}>
																	<Button type={'primary'}>Explore Courses</Button>
																</Link>
															)}
														</div>
													</>
												)}

												<div className="row pt-1 g-4">
													{data.enrolled_courses.map((course) => (
														<div
															className="col-lg-3"
															key={course.id}
														>
															<CourseCard course={course} />
														</div>
													))}
												</div>
											</>
										),
									},
									{
										key: '2',
										label: 'Status Updates',
										children: (
											<>
												<div className="d-flex align-items-center pb-3 justify-content-end">
													{data.user.id === user?.id && (
														<Button
															type="primary"
															icon={<PlusCircleOutlined />}
															onClick={() => setStatusModalOpen(true)}
														>
															Post New Status
														</Button>
													)}
												</div>

												{data.status_updates.length === 0 && (
													<NoData
														height={'40vh'}
														message={'No status updates available.'}
													/>
												)}

												<div className="d-flex flex-column pb-4 gap-3 w-100">
													{data.status_updates.map((status) => (
														<Card
															key={status.id}
															styles={{
																body: {
																	padding: 10,
																},
															}}
															hoverable
															className="rounded-0"
														>
															<p className="mb-0 fs-6 fw-bold">{status.status}</p>
															<div className="d-flex align-items-center gap-2">
																<CalendarOutlined />
																<p className="mb-0 mt-1">
																	{new Date(status.created_at).toLocaleDateString('en-US', {
																		month: 'long',
																		day: 'numeric',
																		year: 'numeric',
																	})}
																</p>
															</div>
														</Card>
													))}
												</div>
											</>
										),
									},
									...(data.user.id === user?.id
										? [
												{
													key: '3',
													label: 'Feedbacks',
													children: (
														<>
															{data.user.id === user?.id && (
																<>
																	{userFeedbackLoading && <Loader height="40dvh" />}

																	{userFeedbackError && <APIError height={'40dvh'} />}

																	{userFeedback && userFeedback.length === 0 && (
																		<NoData
																			height={'40vh'}
																			message={'No feedbacks available yet.'}
																		/>
																	)}

																	{userFeedback && userFeedback.length > 0 && (
																		<div className="d-flex flex-column gap-3">
																			{userFeedback.map((item) => (
																				<Card
																					key={item.id}
																					styles={{
																						body: {
																							padding: 10,
																						},
																					}}
																					hoverable
																					className="rounded-0"
																				>
																					<span className="fw-bold">"{item.feedback}"</span> in{' '}
																					<Link
																						to={`/course/${item.course.id}`}
																						className="text-decoration-none"
																					>
																						{item.course.name}
																					</Link>
																					<div className="d-flex align-items-center gap-2">
																						<CalendarOutlined />
																						<p className="mb-0 mt-1">
																							{new Date(item.created_at).toLocaleDateString('en-US', {
																								month: 'long',
																								day: 'numeric',
																								year: 'numeric',
																							})}
																						</p>
																					</div>
																				</Card>
																			))}
																		</div>
																	)}
																</>
															)}
														</>
													),
												},
										  ]
										: []),
								]}
								size="large"
							/>
						</>
					)}

					<AddStatusModal
						open={statusModalOpen}
						close={() => setStatusModalOpen(false)}
						refetch={refetch}
					/>
				</>
			)}
		</Layout>
	);
};

export default Profile;
