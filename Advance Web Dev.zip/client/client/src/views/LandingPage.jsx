import { useQuery } from '@tanstack/react-query';
import { useContext } from 'react';
import Layout from '../Layout/Layout';
import APIError from '../components/APIError';
import CourseCard from '../components/CourseCard';
import Loader from '../components/Loader';
import NoData from '../components/NoData';
import UserCard from '../components/UserCard';
import axios from '../config/axios';
import { AuthContext } from '../context/AuthContext';

const LandingPage = () => {
	const { user } = useContext(AuthContext);

	// get all courses query for students
	const {
		data: coursesForStudents,
		isLoading: coursesForStudentsLoading,
		isError: coursesForStudentsError,
		refetch: coursesForStudentsRefetch,
	} = useQuery({
		queryKey: ['courses'],
		queryFn: async () => {
			const { data } = await axios.get('/courses', { withCredentials: true });
			return data;
		},
		enabled: user?.role === 'student',
	});

	// get all courses query for teachers
	const {
		data: coursesForTeachers,
		isLoading: coursesForTeachersLoading,
		isError: coursesForTeachersError,
	} = useQuery({
		queryKey: ['courses_for_teacher'],
		queryFn: async () => {
			const { data } = await axios.get('/courses', { withCredentials: true, params: { own_courses: 'True' } });
			return data;
		},
		enabled: user?.role === 'teacher',
	});

	// get discover users query
	const {
		data: discoverUsers,
		isLoading: discoverUsersLoading,
		isError: discoverUsersError,
	} = useQuery({
		queryKey: ['discover_users'],
		queryFn: async () => {
			const { data } = await axios.get('/users/discover', { withCredentials: true });
			return data;
		},
	});

	return (
		<Layout>
			{user?.role === 'teacher' && (
				<>
					<div className="fs-3 fw-bold border-bottom pb-1">My Dashboard</div>

					{coursesForTeachersLoading && <Loader height={'70vh'} />}

					{coursesForTeachersError && <APIError height={'70vh'} />}

					{coursesForTeachers && coursesForTeachers.length === 0 && (
						<NoData
							height={'70vh'}
							message={'No Courses available. Create new one.'}
						/>
					)}

					{coursesForTeachers && coursesForTeachers.length > 0 && (
						<div className="row pt-3 g-4">
							{coursesForTeachers.map((course) => (
								<div
									className="col-lg-3"
									key={course.id}
								>
									<CourseCard course={course} />
								</div>
							))}
						</div>
					)}
				</>
			)}

			{user?.role === 'student' && (
				<>
					<div className="fs-3">Welcome Back, {user?.name}.</div>
					<div className="fs-6 text-muted">Explore all available courses and start learning today!</div>

					{coursesForStudentsLoading && <Loader height="40dvh" />}

					{coursesForStudentsError && <APIError height={'40vh'} />}

					{coursesForStudents && coursesForStudents.length === 0 && (
						<NoData
							height={'70vh'}
							message={'No Courses available. Please check back later.'}
						/>
					)}

					{coursesForStudents && coursesForStudents.length > 0 && (
						<div className="row pt-3 g-4">
							{coursesForStudents.map((course) => (
								<div
									className="col-lg-3"
									key={course.id}
								>
									<CourseCard
										course={course}
										refetch={coursesForStudentsRefetch}
									/>
								</div>
							))}
						</div>
					)}

					<div className="pb-2 pt-4 fs-3">Explore Other Students</div>

					{discoverUsersLoading && <Loader height="30dvh" />}

					{discoverUsersError && <APIError height={'30dvh'} />}

					{discoverUsers && discoverUsers.length === 0 && (
						<NoData
							height={'40vh'}
							message={'No users available yet. Create new one.'}
						/>
					)}

					{discoverUsers && discoverUsers.length > 0 && (
						<div className="row g-4 pb-3">
							{discoverUsers.map((user) => (
								<div
									className="col-lg-3"
									key={user.id}
								>
									<UserCard user={user} />
								</div>
							))}
						</div>
					)}
				</>
			)}
		</Layout>
	);
};

export default LandingPage;
