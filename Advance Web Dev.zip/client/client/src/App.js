import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { App, ConfigProvider } from 'antd';
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import IsLoggedIn from './auth/IsLoggedIn';
import IsStudent from './auth/IsStudent';
import IsTeacher from './auth/IsTeacher';
import { AuthProvider } from './context/AuthContext';
import Auth from './views/Auth';
import CourseDetails from './views/CourseDetails';
import CreateCourse from './views/CreateCourse';
import LandingPage from './views/LandingPage';
import MyLearning from './views/MyLearning';
import NotFound from './views/NotFound';
import Profile from './views/Profile';
import Search from './views/Search';

const router = createBrowserRouter([
	{
		path: '/login',
		element: <Auth />,
	},
	{
		element: <IsLoggedIn />,
		errorElement: <NotFound />,
		children: [
			{
				path: '/',
				element: <LandingPage />,
			},
			{
				path: '/profile/:id',
				element: <Profile />,
			},
			{
				path: '/course/:id',
				element: <CourseDetails />,
			},
		],
	},
	{
		element: <IsStudent />,
		errorElement: <NotFound />,
		children: [
			{
				path: '/my-learning',
				element: <MyLearning />,
			},
		],
	},
	{
		element: <IsTeacher />,
		errorElement: <NotFound />,
		children: [
			{
				path: '/create-course',
				element: <CreateCourse />,
			},
			{
				path: '/search',
				element: <Search />,
			},
		],
	},
]);

const queryClient = new QueryClient();

const colorPrimary = '#dc3545';

export default function Home() {
	return (
		<ConfigProvider
			theme={{
				token: {
					colorPrimary: colorPrimary,
					colorError: 'red',
				},
				components: {
					Button: {
						colorPrimary: `${colorPrimary} !important`,
						colorError: `#FF0000 !important`,
						colorBgContainerDisabled: `#f5f5f5 !important`,
					},
					Badge: {
						colorPrimary: colorPrimary,
						colorBgBase: colorPrimary,
						colorPrimaryActive: colorPrimary,
					},
				},
			}}
			wave={{
				disabled: true,
			}}
		>
			<App>
				<QueryClientProvider client={queryClient}>
					<AuthProvider>
						<RouterProvider router={router} />
					</AuthProvider>
				</QueryClientProvider>
			</App>
		</ConfigProvider>
	);
}
