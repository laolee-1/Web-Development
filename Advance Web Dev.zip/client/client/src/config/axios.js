import axios from 'axios';

//creating an axios instance with auth setup
const axiosInstance = axios.create({
	baseURL: 'http://localhost:8000/api',
	timeout: 40000,
});

axiosInstance.interceptors.request.use((config) => {
	if (config.withCredentials) {
		const deviceId = localStorage.getItem('device_id');
		config.headers['Authorization'] = `Token ${deviceId}`;
	}

	return config;
});

export default axiosInstance;