import { useContext } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const IsStudent = () => {
	const location = useLocation();
	const { isAuthenticated, user } = useContext(AuthContext);

	return isAuthenticated && user?.role === 'student' ? (
		<Outlet />
	) : (
		<Navigate
			to="/login"
			state={{ from: location }}
			replace
		/>
	);
};

export default IsStudent;
