import { useContext } from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';

const IsTeacher = () => {
	const location = useLocation();
	const { isAuthenticated, user } = useContext(AuthContext);

	return isAuthenticated && user?.role === 'teacher' ? (
		<Outlet />
	) : (
		<Navigate
			to="/login"
			state={{ from: location }}
			replace
		/>
	);
};

export default IsTeacher;
