from django.db.models import Q


def filter_users_by_search_term(search_term):
    if search_term is None:
        return Q()
    return Q(username__icontains=search_term) | Q(name__icontains=search_term)


def filter_by_role(role):
    if role is None:
        return Q()
    return Q(role=role)
