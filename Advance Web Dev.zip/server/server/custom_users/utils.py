import math
from app.settings import SECRET_KEY

import jwt
import datetime


# defining access_token_generator function
def access_token_generator(user, days=29):
    """generates and returns an access token
    Args:
        user (User): The user for which the token will be generated
        days : Number of days the token will be valid
    Returns:
        str: access token
    """

    payload = {
        'id': user.id,
        'exp': datetime.datetime.utcnow() + datetime.timedelta(days=days, minutes=155),
        'iat': datetime.datetime.utcnow()
    }

    access_token = jwt.encode(payload,
                              SECRET_KEY, algorithm='HS256')

    return access_token
