from django.db import models
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from django.core.validators import MaxLengthValidator, MinLengthValidator


# custom account manager
class CustomAccountManager(BaseUserManager):

    def create_superuser(self, username, name, dp, role, password,
                         **other_fields):

        other_fields.setdefault('is_staff', True)
        other_fields.setdefault('is_superuser', True)

        if other_fields.get('is_superuser') is not True:
            raise ValueError(
                'Superuser must be assigned to is_superuser=True.')

        return self.create_user(username, name, dp, role, password,
                                **other_fields)

    def create_user(self, username, name, dp, role, password,
                    **other_fields):

        if not username:
            raise ValueError(_('Username must be provided'))

        user = self.model(username=username,
                          name=name,
                          dp=dp,
                          role=role,
                          password=password,
                          **other_fields)
        user.set_password(password)
        user.save()
        return user


# custom account manager
class User(AbstractBaseUser, PermissionsMixin):
    role_choices = (
        ('teacher', 'Teacher'),
        ('student', 'Student'),
    )

    username = models.CharField(
        _('username'),
        max_length=115,
        unique=True,
        validators=[
            MinLengthValidator(5),
            MaxLengthValidator(15),
        ],
        null=False,
        blank=False
    )
    name = models.CharField(max_length=100, null=True, blank=True)
    dp = models.CharField(max_length=255, null=True, blank=True)
    role = models.CharField(max_length=20, null=False, blank=False, choices=role_choices)
    password = models.CharField(max_length=255, null=True, blank=True)

    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    objects = CustomAccountManager()

    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = ['name', 'role', 'dp']

    def __str__(self):
        return f'{self.username}, {self.name}'


class Status(models.Model):
    status = models.TextField(max_length=2000, null=False, blank=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.status
