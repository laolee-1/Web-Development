from rest_framework import permissions


class IsUserTeacher(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.role == 'teacher'


class IsUserStudent(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.role == 'student'
