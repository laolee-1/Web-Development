from rest_framework import serializers

from .models import User, Status


class UserRegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'

    def create(self, validated_data):
        user = User.objects.create_user(
            validated_data['username'],
            validated_data['name'],
            validated_data['dp'],
            validated_data['role'],
            validated_data['password'], )

        return user


class UserReadSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        exclude = ('password',)


class UserStatusWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Status
        fields = '__all__'


