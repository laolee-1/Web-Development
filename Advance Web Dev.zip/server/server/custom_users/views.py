from django.core.files.storage import FileSystemStorage
from django.shortcuts import get_object_or_404
from rest_framework import status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from .queries import filter_users_by_search_term, filter_by_role
from courses.models import Course
from courses.serializers import CourseReadSerializer
from custom_users.models import User, Status
from custom_users.permissions import IsUserTeacher
from custom_users.serializers import UserRegistrationSerializer, UserReadSerializer, UserStatusWriteSerializer
from custom_users.utils import access_token_generator


@api_view(['POST'])
@permission_classes([AllowAny])
def user_registration(request):
    data = request.data.copy()

    serializer = UserRegistrationSerializer(data=data, many=False)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['POST'])
@permission_classes([AllowAny])
def user_login(request):
    data = request.data.copy()
    if 'username' not in data or 'password' not in data:
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)

    user = User.objects.filter(username=data['username']).first()
    if user is None:
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)

    if not user.check_password(data['password']):
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)

    user_data = UserReadSerializer(user).data
    # generating access token
    access_token = access_token_generator(user)

    # creating response object
    response = Response()
    response.data = {
        'access_token': access_token,
        'user': user_data
    }

    return response


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def verify_jwt_validity(request):
    user = request.user
    user_data = UserReadSerializer(user).data

    return Response(user_data, status=status.HTTP_200_OK)


class FileUploadView(APIView):
    def post(self, request, format=None):
        uploaded_file = request.FILES['file']
        fs = FileSystemStorage()
        filename = fs.save(uploaded_file.name, uploaded_file)
        uploaded_file_path = fs.url(filename)
        return Response({'file_path': uploaded_file_path}, status=status.HTTP_201_CREATED)





@api_view(['GET'])
@permission_classes([IsUserTeacher])
def filter_all_users(request):
    params = request.query_params
    users = User.objects.filter(
        filter_users_by_search_term(params.get('search_term')) & filter_by_role(params.get('role')))
    serializer = UserReadSerializer(users, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def create_status_update(request):
    data = request.data.copy()
    data['user'] = request.user.id

    serializer = UserStatusWriteSerializer(data=data, many=False)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_user_information(request, pk):
    user = get_object_or_404(User, pk=pk)

    user_data = UserReadSerializer(user).data

    raw_enrolled_courses = Course.objects.filter(students=user).order_by('-id')
    enrolled_courses = CourseReadSerializer(raw_enrolled_courses, many=True).data

    raw_created_courses = Course.objects.filter(teacher=user).order_by('-id')
    created_courses = CourseReadSerializer(raw_created_courses, many=True).data

    raw_status_updates = Status.objects.filter(user=user).order_by('-id')
    status_updates = UserStatusWriteSerializer(raw_status_updates, many=True).data

    response = Response()
    response.data = {
        'user': user_data,
        'enrolled_courses': enrolled_courses,
        'created_courses': created_courses,
        'status_updates': status_updates
    }

    return response


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def discover_users(request):
    # query any 2 random custom_users
    students = User.objects.filter(role='student').order_by('?')[:2]
    serializer = UserReadSerializer(students, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)
