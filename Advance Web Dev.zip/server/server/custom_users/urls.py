from rest_framework.urls import path

from .views import user_registration, user_login, FileUploadView, filter_all_users, create_status_update, get_user_information, discover_users, \
    verify_jwt_validity

urlpatterns = [
    path('users/register', user_registration, name='register'),
    path('users/login', user_login, name='login'),
    path('users/authenticate', verify_jwt_validity, name='authenticate'),

    path('users/file-upload', FileUploadView.as_view(), name='file-upload'),

    path('users/search', filter_all_users, name='search_users'),
    path('users/status-update', create_status_update, name='add_status_update'),
    path('users/<int:pk>', get_user_information, name='get_user_details'),
    path('users/discover', discover_users, name='discover_users'),
]
