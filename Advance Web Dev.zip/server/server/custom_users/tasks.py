# tasks.py

from celery import shared_task
from django.core.files.storage import FileSystemStorage

@shared_task
def process_uploaded_file(file_name, file_content):
    fs = FileSystemStorage()
    filename = fs.save(file_name, file_content)
    uploaded_file_path = fs.url(filename)
    print('file path: ', uploaded_file_path)
    return uploaded_file_path
