# course_group_chat/routing.py
from django.urls import re_path

from . import consumers

websocket_urlpatterns = [
    re_path(r"ws/course_group_chat/(?P<room_name>\w+)/$", consumers.CourseGroupChatConsumer.as_asgi()),
]