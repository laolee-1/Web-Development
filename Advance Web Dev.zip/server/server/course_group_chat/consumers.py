import json
from channels.generic.websocket import WebsocketConsumer
from asgiref.sync import async_to_sync

from courses.models import Course
from custom_users.models import User


class CourseGroupChatConsumer(WebsocketConsumer):
    course = None

    def connect(self):
        self.room_name = self.scope['url_route']['kwargs']['room_name']
        self.room_group_name = 'live_editor_%s' % self.room_name

        # checking if course exists
        self.course = Course.objects.filter(id=self.room_name).first()
        if self.course is None:
            self.close()

        # Join room group
        async_to_sync(self.channel_layer.group_add)(
            self.room_group_name,
            self.channel_name
        )

        self.accept()

    def disconnect(self, close_code):
        # Leave room group
        async_to_sync(self.channel_layer.group_discard)(
            self.room_group_name,
            self.channel_name
        )

    def receive(self, text_data):
        text_data_json = json.loads(text_data)

        # checking if user enrolled in this course
        user = User.objects.filter(id=text_data_json['user_id']).first()
        if user.role == 'student':
            if user not in self.course.students.all():
                self.close()

        # Send message to room group
        async_to_sync(self.channel_layer.group_send)(
            self.room_group_name,
            {
                'type': 'course_group_chat',
                'data': text_data_json
            }
        )

    # Receive message from room group
    def course_group_chat(self, event):
        # Send message to WebSocket
        self.send(text_data=json.dumps(event))
