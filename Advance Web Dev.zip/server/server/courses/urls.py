from rest_framework.urls import path

from .views import CreateAndGetCourses, enroll_to_a_course, get_course_student_list, create_course_material, get_all_course_materials, \
    submit_course_feedback, get_all_course_feedbacks, get_course_by_id, get_submitted_course_feedbacks, add_course_private_notes_in_bulk, \
    get_course_private_notes

urlpatterns = [
    path('courses', CreateAndGetCourses.as_view(), name='course_list'),
    path('courses/enroll/<int:course_id>', enroll_to_a_course, name='enroll_course'),
    path('courses/<int:course_id>', get_course_by_id, name='get_course'),
    path('courses/enrolled-students/<int:course_id>', get_course_student_list,
         name='get_course_enrolled_students'),

    path('courses/add-material/<int:course_id>', create_course_material, name='add_course_material'),
    path('courses/materials/<int:course_id>', get_all_course_materials, name='get_course_materials'),

    path('courses/add-feedback/<int:course_id>', submit_course_feedback, name='add_course_feedback'),
    path('courses/feedbacks/<int:course_id>', get_all_course_feedbacks, name='get_course_feedbacks'),
    path('courses/own-feedbacks', get_submitted_course_feedbacks, name='get_own_feedbacks'),

    path('courses/add-private-notes-in-bulk/<int:course_id>', add_course_private_notes_in_bulk,
         name='add_course_private_notes_in_bulk'),
    path('courses/private-notes/<int:course_id>', get_course_private_notes, name='get_course_private_notes'),
]
