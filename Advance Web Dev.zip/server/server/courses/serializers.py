from rest_framework import serializers

from custom_users.serializers import UserReadSerializer
from .models import Course, CourseMaterial, CourseFeedback, CoursePrivateNotes


class CourseWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Course
        exclude = ['students']


class CourseReadSerializer(serializers.ModelSerializer):
    teacher = UserReadSerializer(read_only=True, many=False)

    class Meta:
        model = Course
        fields = '__all__'


class CourseMaterialSerializer(serializers.ModelSerializer):
    class Meta:
        model = CourseMaterial
        fields = '__all__'


class CourseFeedbackWriteSerializer(serializers.ModelSerializer):
    class Meta:
        model = CourseFeedback
        fields = '__all__'


class CourseFeedbackReadSerializer(serializers.ModelSerializer):
    student = UserReadSerializer(read_only=True, many=False)
    course = CourseReadSerializer(read_only=True, many=False)

    class Meta:
        model = CourseFeedback
        fields = '__all__'


class CoursePrivateNotesSerializer(serializers.ModelSerializer):
    class Meta:
        model = CoursePrivateNotes
        fields = '__all__'
