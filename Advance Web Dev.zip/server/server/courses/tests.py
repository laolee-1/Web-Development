from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from django.contrib.auth import get_user_model
from courses.models import Course
from custom_users.models import User


class CourseTests(APITestCase):
    def setUp(self):
        self.teacher_user = User.objects.create_user(username='teacher', password='password123', role='teacher',
                                                     name='User 1', dp='dp1')
        self.student_user = User.objects.create_user(username='student', password='password123', role='student',
                                                     name='User 2', dp='dp2')
        self.course = Course.objects.create(name='Test Course', code='TST101', description='Test Description',
                                            teacher=self.teacher_user)
        self.course.students.add(self.student_user)

    def test_create_course(self):
        self.client.force_authenticate(user=self.teacher_user)
        url = '/api/courses'
        data = {'name': 'New Course', 'code': 'NEW101', 'description': 'New Description'}
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(Course.objects.count(), 2)

    def test_get_all_courses_as_teacher(self):
        self.client.force_authenticate(user=self.teacher_user)
        url = '/api/courses'
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]['name'], 'Test Course')

    def test_get_own_courses_as_teacher(self):
        self.client.force_authenticate(user=self.teacher_user)
        url = '/api/courses?own_courses=True'
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]['name'], 'Test Course')

    def test_get_own_courses_as_student(self):
        self.client.force_authenticate(user=self.student_user)
        url = '/api/courses?own_courses=True'
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 1)
        self.assertEqual(response.data[0]['name'], 'Test Course')
