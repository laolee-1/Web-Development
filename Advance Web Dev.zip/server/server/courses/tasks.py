from celery import shared_task
from courses.models import CoursePrivateNotes, Course


@shared_task
def process_bulk_class_notes(notes, course_id):
    course = Course.objects.filter(id=course_id).first()
    for note in notes:
        print('Celery worker processing note:', note, 'for course:', course)
        CoursePrivateNotes.objects.create(note=note, course=course)
