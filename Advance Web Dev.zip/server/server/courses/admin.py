from django.contrib import admin

from .models import CoursePrivateNotes

admin.site.register(CoursePrivateNotes)
