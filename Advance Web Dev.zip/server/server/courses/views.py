from django.shortcuts import render
from rest_framework import status, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.views import APIView

from courses.models import Course, CourseFeedback
from courses.serializers import CourseWriteSerializer, CourseReadSerializer, CourseMaterialSerializer, \
    CourseFeedbackWriteSerializer, CourseFeedbackReadSerializer, CoursePrivateNotesSerializer
from custom_users.permissions import IsUserTeacher, IsUserStudent
from custom_users.serializers import UserReadSerializer
from .tasks import process_bulk_class_notes


class CreateAndGetCourses(APIView):
    permission_classes = [IsUserTeacher]

    # make get method available to IsAuthenticated
    def get_permissions(self):
        if self.request.method == 'GET':
            return [permissions.IsAuthenticated()]
        return super().get_permissions()

    def post(self, request):
        data = request.data.copy()
        data['teacher'] = request.user.id

        serializer = CourseWriteSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def get(self, request):
        params = request.query_params
        if params.get('own_courses') is None:
            raw_courses = Course.objects.all()
        else:
            if request.user.role == 'teacher':
                raw_courses = Course.objects.filter(teacher=request.user)
            else:
                raw_courses = Course.objects.filter(students__in=[request.user])

        serializer = CourseReadSerializer(raw_courses, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_course_by_id(request, course_id):
    course = Course.objects.filter(id=course_id).first()

    # check if course exists
    if course is None:
        return Response(status=status.HTTP_404_NOT_FOUND)

    # check if user is enrolled in this course
    if request.user.role == 'teacher':
        if course.teacher != request.user:
            return Response(status=status.HTTP_403_FORBIDDEN)
    else:
        if request.user not in course.students.all():
            return Response(status=status.HTTP_403_FORBIDDEN)

    serializer = CourseReadSerializer(course)
    return Response(serializer.data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes([IsUserStudent])
def enroll_to_a_course(request, course_id):
    course = Course.objects.filter(id=course_id).first()

    # check if course exists
    if course is None:
        return Response(status=status.HTTP_404_NOT_FOUND)

    # check if user is already enrolled
    if request.user in course.students.all():
        return Response(status=status.HTTP_400_BAD_REQUEST)
    course.students.add(request.user)

    return Response(status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsUserTeacher])
def get_course_student_list(request, course_id):
    course = Course.objects.filter(id=course_id).first()

    # check if course exists
    if course is None:
        return Response(status=status.HTTP_404_NOT_FOUND)

    # check is teacher owns this course
    if course.teacher != request.user:
        return Response(status=status.HTTP_403_FORBIDDEN)

    students = course.students.all()
    serializer = UserReadSerializer(students, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes([IsUserTeacher])
def create_course_material(request, course_id):
    course = Course.objects.filter(id=course_id).first()

    # check if course exists
    if course is None:
        return Response(status=status.HTTP_404_NOT_FOUND)

    # check is teacher owns this course
    if course.teacher != request.user:
        return Response(status=status.HTTP_403_FORBIDDEN)

    data = request.data.copy()
    data['course'] = course.id

    serializer = CourseMaterialSerializer(data=data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_all_course_materials(request, course_id):
    course = Course.objects.filter(id=course_id).first()

    # check if course exists
    if course is None:
        return Response(status=status.HTTP_404_NOT_FOUND)

    # check if user is enrolled in this course
    if request.user.role == 'teacher':
        if course.teacher != request.user:
            return Response(status=status.HTTP_403_FORBIDDEN)
    else:
        if request.user not in course.students.all():
            return Response(status=status.HTTP_403_FORBIDDEN)

    materials = course.coursematerial_set.all()
    serializer = CourseMaterialSerializer(materials, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes([IsUserStudent])
def submit_course_feedback(request, course_id):
    course = Course.objects.filter(id=course_id).first()

    # check if course exists
    if course is None:
        return Response(status=status.HTTP_404_NOT_FOUND)

    # check if user is enrolled in this course
    if request.user not in course.students.all():
        return Response(status=status.HTTP_403_FORBIDDEN)

    data = request.data.copy()
    data['course'] = course.id
    data['student'] = request.user.id

    serializer = CourseFeedbackWriteSerializer(data=data)
    if serializer.is_valid():
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


@api_view(['GET'])
@permission_classes([IsUserTeacher])
def get_all_course_feedbacks(request, course_id):
    course = Course.objects.filter(id=course_id).first()

    # check if course exists
    if course is None:
        return Response(status=status.HTTP_404_NOT_FOUND)

    # check is teacher owns this course
    if course.teacher != request.user:
        return Response(status=status.HTTP_403_FORBIDDEN)

    feedbacks = course.coursefeedback_set.all()
    serializer = CourseFeedbackReadSerializer(feedbacks, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsUserStudent])
def get_submitted_course_feedbacks(request):
    feedbacks = CourseFeedback.objects.filter(student=request.user)
    serializer = CourseFeedbackReadSerializer(feedbacks, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)


@api_view(['POST'])
@permission_classes([IsUserTeacher])
def add_course_private_notes_in_bulk(request, course_id):
    data = request.data.copy()
    course = Course.objects.filter(id=course_id).first()

    if course is None:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if data.get('notes') is None:
        return Response(status=status.HTTP_400_BAD_REQUEST)

    process_bulk_class_notes.delay(data['notes'], course_id)

    return Response(status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsAuthenticated, IsUserTeacher])
def get_course_private_notes(request, course_id):
    course = Course.objects.filter(id=course_id).first()

    if course is None:
        return Response(status=status.HTTP_404_NOT_FOUND)

    if course.teacher != request.user:
        return Response(status=status.HTTP_403_FORBIDDEN)

    notes = course.courseprivatenotes_set.all()
    serializer = CoursePrivateNotesSerializer(notes, many=True)
    return Response(serializer.data, status=status.HTTP_200_OK)
